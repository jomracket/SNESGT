SNESGT Ver 0.218
Copyright (c)GIGO,Hii 2001-2007


--------------------
 System requirement
--------------------
 * Windows 2000/XP/Vista


--------------------
 Command line option
--------------------
 * -f Start up in fullscreen mode


--------------------
 Archive file
--------------------
 * Archive file is supported with 'Common Archivers Library' DLL.

   Common Archivers Library
   http://www.csdinc.co.jp/archiver/index-e.html


--------------------
  Contact
-----------
 url : http://gigo.retrogames.com/


